(function(){
    function createOverlay(url){
        if(!url) return;
        const existing = document.getElementById('unblock-overlay');
        if(existing) existing.remove();
        const overlay = document.createElement('div');
        overlay.id = 'unblock-overlay';
        Object.assign(overlay.style,{
            position: 'fixed',
            left: '0',
            top: '0',
            width: '100%',
            height: '100%',
            margin: '0',
            padding: '0',
            zIndex: 2147483647,
            background: '#000'
        });

        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'Close';
        Object.assign(closeBtn.style,{
            position: 'absolute',
            right: '12px',
            top: '12px',
            zIndex: 2147483648,
            padding: '8px 12px',
            background: '#FF5A09',
            color: '#fff',
            border: 'none',
            cursor: 'pointer'
        });
        closeBtn.addEventListener('click', ()=> overlay.remove());

        const iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        iframe.style.border = '0';
        iframe.style.display = 'block';

        overlay.appendChild(closeBtn);
        overlay.appendChild(iframe);
        document.body.appendChild(overlay);
    }

    function sanitizeUrl(input){
        if(!input || typeof input !== 'string') return null;
        input = input.trim();
        if(/^(javascript|data|vbscript|file):/i.test(input)) return null;
        if(!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(input)){
            input = 'https://' + input;
        }
        try{
            const u = new URL(input);
            if(!['http:', 'https:'].includes(u.protocol)) return null;
            return u.toString();
        }catch(e){
            return null;
        }
    }

    window.uwebsite = function(){
        createOverlay('https://bing.com');
    };

    window.usweb = function(){
        const thevalue = document.getElementById('thesite').value;
        const safe = sanitizeUrl(thevalue);
        if(!safe){
            alert('Invalid or disallowed URL');
            return;
        }
        createOverlay(safe);
    };

    window.uvideo = function(){
        const thevalue = document.getElementById('thevideo').value;
        if(!thevalue){ alert('Enter a video link'); return; }
        const encoded = encodeURIComponent(thevalue.trim());
        const target = 'https://ytunblock.glitch.me/downloadvid?v=' + encoded;
        createOverlay(target);
    };
})();
