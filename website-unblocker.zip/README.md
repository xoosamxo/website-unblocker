# Description
Unblocks websites and Youtube videos. Used to bypass school or company system and internet-based blocks.

# Deployment
To deploy and use Website Unblocker on your site, upload all files to your hosting excluding README.md and LICENSE. Once the files are uploaded, the website is ready to be viewed and used.

# Demo
A demo of Website Unblocker can be viewed and used on [My Website](http://influxes.tk/unblock/ "Unblocker"). This project is free and open source for anyone to use.

# License
Website Unblocker and all of its components is released under the MIT license.
